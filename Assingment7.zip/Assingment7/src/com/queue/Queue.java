package com.queue;
 
public class Queue {
	private int maxSize;
	private int[] queueArray;
	private int front;
	private int rear;
	private int currentSize;
 
	public Queue(int size) {
		this.maxSize = size;
		this.queueArray = new int[maxSize];
		this.front = 0;
		this.rear = -1;
		this.currentSize = 0;
	}
 
	public boolean isEmpty() {
		return currentSize == 0;
	}
 
	public boolean isFull() {
		return currentSize == maxSize;
	}
 
	public void enqueue(int data) {
		if (isFull()) {
			System.out.println("Queue Overflow");
		} else {
			rear = (rear + 1) % maxSize;
			queueArray[rear] = data;
			currentSize++;
		}
	}
 
	public int dequeue() {
		if (isEmpty()) {
			System.out.println("Queue Underflow");
			return -1;
		} else {
			int data = queueArray[front];
			front = (front + 1) % maxSize;
			currentSize--;
			return data;
		}
	}
 
	public void display() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
		} else {
			System.out.print("Elements in queue: ");
			int count = 0;
			int index = front;
			while (count < currentSize) {
				System.out.print(queueArray[index] + " ");
				index = (index + 1) % maxSize;
				count++;
			}
			System.out.println();
		}
	}
 
	public static void main(String[] args) {
		Queue queue = new Queue(5);
		queue.enqueue(10);
		queue.enqueue(20);
		queue.enqueue(30);
		queue.enqueue(40);
		queue.display();
 
		int removedElement = queue.dequeue();
		System.out.println("After removing first element: ");
		queue.display();
	}
}