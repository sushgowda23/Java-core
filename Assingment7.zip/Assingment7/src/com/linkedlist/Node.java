package com.linkedlist;
class Node
{
	double data;
	Node next;
 
	Node(double data)
	{
		this.data = data;
		this.next = null;
	}
}
 
class Stack {
	private Node top;
 
	public Stack() {
		this.top = null;
	}
 
	public boolean isEmpty() {
		return top == null;
	}
 
	public void push(double data) {
		Node newNode = new Node(data);
		if (isEmpty()) {
			top = newNode;
		} else {
			newNode.next = top;
			top = newNode;
		}
	}
 
	public double pop() {
		if (isEmpty()) {
			System.out.println("Stack Underflow");
			return Double.NaN;
		} else {
			double data = top.data;
			top = top.next;
			return data;
		}
	}
 
	public double peek() {
		if (isEmpty()) {
			System.out.println("Stack is empty");
			return Double.NaN;
		} else {
			return top.data;
		}
	}
 
	public void display() {
		if (isEmpty()) {
			System.out.println("Stack is empty");
		} else {
			Node current = top;
			System.out.println("Elements in stack:");
			while (current != null) {
				System.out.println(current.data);
				current = current.next;
			}
		}
	}
}