package com.p3.controlstructure;

import java.util.Scanner;

public class GradeChecker {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
Scanner scanner = new Scanner(System.in);
 
        // Prompt the user to enter the percentage
        System.out.print("Enter the percentage: ");
        double percentage = scanner.nextDouble();
 
        // Close the scanner
        scanner.close();
 
        // Check the grade based on the percentage
        if (percentage >= 60) {
            System.out.println("Grade A");
        } else if (percentage >= 45) {
            System.out.println("Grade B");
        } else if (percentage >= 35) {
            System.out.println("Grade C");
        } else {
            System.out.println("Fail");
        }
    }
}
