package com.p3.controlstructure;

import java.util.Scanner;

public class RightAngleTriangle {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
Scanner scanner = new Scanner(System.in);
 
        // Prompt the user to enter the number of rows
        System.out.print("Enter the number of rows: ");
        int numRows = scanner.nextInt();
 
        // Close the scanner
        scanner.close();
 
        // Iterate to print each row of the pattern
        for (int i = 1; i <= numRows; i++) {
            // Print the numbers for the current row
            for (int j = 1; j <= i; j++) {
                System.out.print(i);
            }
            // Move to the next line after printing each row
            System.out.println();
        }
    }
}