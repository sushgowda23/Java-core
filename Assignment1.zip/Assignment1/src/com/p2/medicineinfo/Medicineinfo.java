package com.p2.medicineinfo;

public interface Medicineinfo {
	void displayLabel();
}

// Tablet class implementing MedicineInfo interface
class Tablet implements Medicineinfo {
    @Override
    public void displayLabel() {
        System.out.println("Store Tablets in a cool dry place.");
    }
}

// Syrup class implementing MedicineInfo interface
class Syrup implements Medicineinfo {
    @Override
    public void displayLabel() {
        System.out.println("Syrup is consumable only on prescription.");
    }
}

// Ointment class implementing MedicineInfo interface
class Ointment implements Medicineinfo {
    @Override
    public void displayLabel() {
        System.out.println("Ointment is for external use only.");
    }
}

