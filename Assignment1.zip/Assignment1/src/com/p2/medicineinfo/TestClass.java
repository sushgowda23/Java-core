package com.p2.medicineinfo;

public class TestClass {

	public static void main(String[] args) {
        // Declare Medicine instances
        Medicineinfo tablet = new Tablet();
        Medicineinfo syrup = new Syrup();
        Medicineinfo ointment = new Ointment();

        // Check the polymorphic behavior of the displayLabel() method
        tablet.displayLabel();
        syrup.displayLabel();
        ointment.displayLabel();
    }
}
