package com.specificelementusinglinear;
 
import java.util.Scanner;
 
public class LinearSearch {
	public static boolean linearSearch(int[] arr, int key) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == key) {
				return true;
			}
		}
		return false;
	}
 
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int size = scanner.nextInt();
		int[][] arrays = new int[size][];
 
		
		System.out.println("Enter the elements of each array:");
		for (int i = 0; i < size; i++) {
			int length = scanner.nextInt();
			arrays[i] = new int[length];
			for (int j = 0; j < length; j++) {
				arrays[i][j] = scanner.nextInt();
			}
		}
 
		System.out.print("Enter the element to search: ");
		int key = scanner.nextInt();
 
	
		System.out.println("Output:");
		for (int i = 0; i < size; i++) {
			boolean found = linearSearch(arrays[i], key);
			if (found) {
				System.out.println("Element is Present in Array " + (i + 1));
			} else {
				System.out.println("Element is Not Present in Array " + (i + 1));
			}
		}
	}
}
