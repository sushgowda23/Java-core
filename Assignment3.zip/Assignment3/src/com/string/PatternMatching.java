package com.string;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PatternMatching {
	
		 
		public static void main(String[] args) {
			String[] dictionary = { "abb", "abc", "xyz", "xyy" };
			String pattern = "foo";
	 
			List<String> matchingStrings = findMatchingStrings(dictionary, pattern);
			System.out.println("Strings in the dictionary that match the pattern:");
			for (String str : matchingStrings) {
				System.out.println(str);
			}
		}
	 
		public static List<String> findMatchingStrings(String[] dictionary, String pattern) {
			List<String> result = new ArrayList<>();
			String patternSignature = getPatternSignature(pattern);
	 
			for (String word : dictionary) {
				if (word.length() == pattern.length() && getPatternSignature(word).equals(patternSignature)) {
					result.add(word);
				}
			}
	 
			return result;
		}
	 
		private static String getPatternSignature(String str) {
			Map<Character, Integer> charMap = new HashMap<>();
			StringBuilder signature = new StringBuilder();
	 
			int index = 0;
			for (char ch : str.toCharArray()) {
				if (!charMap.containsKey(ch)) {
					charMap.put(ch, index++);
				}
				signature.append(charMap.get(ch));
			}
	 
			return signature.toString();
		}
	}
