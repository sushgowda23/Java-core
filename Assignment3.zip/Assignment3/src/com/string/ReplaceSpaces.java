package com.string;

import java.util.Scanner;

public class ReplaceSpaces {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String input = scanner.nextLine();
 
		String replacedString = replaceSpaces(input);
		System.out.println("String with spaces replaced: " + replacedString);
 
		scanner.close();
	}
 
	public static String replaceSpaces(String str) {
		StringBuilder result = new StringBuilder();
		for (char ch : str.toCharArray()) {
			if (ch == ' ') {
				result.append("%20");
			} else {
				result.append(ch);
			}
		}
		return result.toString();
	}
}
