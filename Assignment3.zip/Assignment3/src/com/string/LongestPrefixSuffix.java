package com.string;

import java.util.Scanner;

public class LongestPrefixSuffix {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the string: ");
		String s = scanner.next();
 
		int result = longestPrefixSuffixLength(s);
		System.out.println("Length of the longest prefix which is also a suffix: " + result);
 
		scanner.close();
	}
 
	public static int longestPrefixSuffixLength(String s) {
		int n = s.length();
		int[] pi = new int[n];
 
		int j = 0;
		for (int i = 1; i < n; i++) {
			while (j > 0 && s.charAt(i) != s.charAt(j)) {
				j = pi[j - 1];
			}
			if (s.charAt(i) == s.charAt(j)) {
				pi[i] = j + 1;
				j++;
			}
		}
		return pi[n - 1];
	}
}
