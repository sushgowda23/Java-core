package com.string;

import java.util.*;
 
public class StringCircle {
 
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the number of strings: ");
		int n = scanner.nextInt();
		String[] strings = new String[n];
		System.out.println("Enter the strings:");
		for (int i = 0; i < n; i++) {
			strings[i] = scanner.next();
		}
 
		if (canFormCircle(strings)) {
			System.out.println("The given strings can be chained to form a circle.");
		} else {
			System.out.println("The given strings cannot be chained to form a circle.");
		}
 
		scanner.close();
	}
 
	public static boolean canFormCircle(String[] strings) {
		if (strings == null || strings.length == 0) {
			return false;
		}
 
		Map<Character, List<String>> graph = new HashMap<>();
		for (String str : strings) {
			char startChar = str.charAt(0);
			char endChar = str.charAt(str.length() - 1);
			if (!graph.containsKey(startChar)) {
				graph.put(startChar, new ArrayList<>());
			}
			graph.get(startChar).add(str);
			if (!graph.containsKey(endChar)) {
				graph.put(endChar, new ArrayList<>());
			}
		}
 
		Set<String> visited = new HashSet<>();
		return dfs(graph, strings[0], visited);
	}
 
	private static boolean dfs(Map<Character, List<String>> graph, String current, Set<String> visited) {
		char endChar = current.charAt(current.length() - 1);
		if (visited.contains(current)) {
			return false;
		}
		visited.add(current);
		if (!graph.containsKey(endChar)) {
			return false;
		}
		for (String next : graph.get(endChar)) {
			if (visited.size() == graph.size() && next.equals(visited.iterator().next())) {
				return true;
			}
			if (dfs(graph, next, visited)) {
				return true;
			}
		}
		visited.remove(current);
		return false;
	}
}