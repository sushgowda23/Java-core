package com.string;

import java.util.Scanner;

public class LastNVowelsCounter {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String input = scanner.nextLine();
		System.out.print("Enter the value of 'n': ");
		int n = scanner.nextInt();
 
		int count = countLastNVowels(input, n);
 
		if (count == -1) {
			System.out.println("Mismatch in Vowel Count");
		} else {
			System.out.println("Number of last " + n + " vowels: " + count);
		}
 
		scanner.close();
	}
 
	public static int countLastNVowels(String str, int n) {
		int vowelCount = 0;
		for (int i = str.length() - 1; i >= 0 && n > 0; i--) {
			char ch = Character.toLowerCase(str.charAt(i));
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				vowelCount++;
				n--;
			}
		}
 
		if (n > 0) {
			return -1;
		}
 
		return vowelCount;
	}
}
