package com.array;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DistinctCombination {
	   public static void findCombinations(int[] arr, int k, int index, StringBuilder current, List<String> result) {
	        if (current.length() == k) {
	            result.add(current.toString());
	            return;
	        }
	        
	        for (int i = index; i < arr.length; i++) {
	            current.append(arr[i]);
	            findCombinations(arr, k, i + 1, current, result);
	            current.deleteCharAt(current.length() - 1);
	        }
	    }
	
	    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the array of numbers: ");
	        String input = scanner.nextLine();
	        int[] arr = new int[input.length()];
	        for (int i = 0; i < input.length(); i++) {
	            arr[i] = Character.getNumericValue(input.charAt(i));
	        }
	
	        System.out.print("Enter the value of k: ");
	        int k = scanner.nextInt();
	
	        List<String> combinations = new ArrayList<>();
	        findCombinations(arr, k, 0, new StringBuilder(), combinations);
	
	        System.out.println("Distinct combinations of length " + k + ":");
	        for (String combination : combinations) {
	            System.out.print(combination + ",");
	        }
	    }
	}