package com.array;

import java.util.Scanner;

public class MainRange {
	 
	   public static void main(String[] args) {
	        // Array of five integer elements ranging from 1 to 40
	        int[] arr = {7, 19, 30, 25, 5};
	        
	        // Input two numbers from the user
	Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter first number (1-40): ");
	        int num1 = scanner.nextInt();
	        System.out.print("Enter second number (1-40): ");
	        int num2 = scanner.nextInt();
	        
	        // Check if both numbers are in the array
	        if (checkBingo(arr, num1, num2)) {
	            System.out.println("Bingo");
	        } else {
	            System.out.println("Not Found");
	        }
	    }
	    
	    public static boolean checkBingo(int[] arr, int num1, int num2) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == num1 && arr[i] == num2) {
	                return true;
	            }
	        }
	        return false;
	    }
	}