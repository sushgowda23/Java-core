import java.util.HashSet;
import java.util.Iterator;

class Product {
    private int productId;
    private String productName;

    public Product(int productId, String productName) {
        this.productId = productId;
        this.productName = productName;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Product Name: " + productName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return productId == product.productId;
    }

    @Override
    public int hashCode() {
        return productId;
    }
}

public class New {
    public static void main(String[] args) {
        HashSet<Product> products = new HashSet<>();

        // Predefined product information
        Product product1 = new Product(1, "Product A");
        Product product2 = new Product(2, "Product B");
        Product product3 = new Product(3, "Product C");
        Product product4 = new Product(4, "Product D");

        // Adding products to HashSet
        products.add(product1);
        products.add(product2);
        products.add(product3);
        products.add(product4);

        // Remove a particular product by product ID
        int productIdToRemove = 3;
        Iterator<Product> iterator = products.iterator();
        while (iterator.hasNext()) {
            Product product = iterator.next();
            if (product.getProductId() == productIdToRemove) {
                iterator.remove();
                System.out.println("Product removed: " + product);
            }
        }

        // Display the updated product set
        System.out.println("Products after removal:");
        for (Product product : products) {
            System.out.println(product);
        }
    }
}