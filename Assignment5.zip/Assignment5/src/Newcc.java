import java.util.TreeSet;

class Person implements Comparable<Person> {
    private int id;
    private String name;
    private int age;
    private double salary;

    public Person(int id, String name, int age, double salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name.toUpperCase() + ", Salary: " + salary;
    }

    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Person person = (Person) obj;
        return id == person.id;
    }

    @Override
    public int compareTo(Person other) {
        return Integer.compare(this.id, other.id);
    }
}

public class Newcc {
    public static void main(String[] args) {
        TreeSet<Person> persons = new TreeSet<>();

        // Predefined person information
        Person person1 = new Person(1, "John", 30, 50000);
        Person person2 = new Person(2, "Alice", 22, 40000);
        Person person3 = new Person(3, "Bob", 28, 60000);
        Person person4 = new Person(4, "Emily", 35, 70000);
        Person person5 = new Person(5, "David", 25, 45000);
        Person person6 = new Person(6, "Linda", 27, 55000);

        // Adding persons to TreeSet
        persons.add(person1);
        persons.add(person2);
        persons.add(person3);
        persons.add(person4);
        persons.add(person5);
        persons.add(person6);

        // Print names of all persons in uppercase
        System.out.println("Names of all persons in uppercase:");
        for (Person person : persons) {
            System.out.println(person.getName().toUpperCase());
        }
    }
}