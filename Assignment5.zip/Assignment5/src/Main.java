import java.util.HashSet;

class Product {
    private int productId;
    private String productName;

    public Product(int productId, String productName) {
        this.productId = productId;
        this.productName = productName;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Product Name: " + productName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return productId == product.productId;
    }

    @Override
    public int hashCode() {
        return productId;
    }
}

public class Main {
    public static void main(String[] args) {
        HashSet<Product> products = new HashSet<>();

        // Predefined product information
        Product product1 = new Product(1, "Product A");
        Product product2 = new Product(2, "Product B");
        Product product3 = new Product(3, "Product C");
        Product product4 = new Product(4, "Product D");

        // Adding products to HashSet
        products.add(product1);
        products.add(product2);
        products.add(product3);
        products.add(product4);

        // List all the product details
        System.out.println("Product Details:");
        for (Product product : products) {
            System.out.println(product);
        }
    }
}