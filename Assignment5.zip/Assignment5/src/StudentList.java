import java.util.ArrayList;

public class StudentList {
    public static void main(String[] args) {
        // Create an ArrayList to store student names
        ArrayList<String> studentNames = new ArrayList<>();

        // Add some student names to the list
        studentNames.add("Alice");
        studentNames.add("Bob");
        studentNames.add("Charlie");
        studentNames.add("David");
        studentNames.add("Emma");

        // Name to search
        String nameToSearch = "Charlie";

        // Check if the name exists in the list
        boolean found = false;
        for (String name : studentNames) {
            if (name.equals(nameToSearch)) {
                found = true;
                break;
            }
        }

        // Display the result
        if (found) {
            System.out.println(nameToSearch + " exists in the list.");
        } else {
            System.out.println(nameToSearch + " does not exist in the list.");
        }
    }
}