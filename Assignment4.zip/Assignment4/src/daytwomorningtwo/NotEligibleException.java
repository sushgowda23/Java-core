package daytwomorningtwo;


class NotEligibleException extends Exception {
    public NotEligibleException(String message) {
        super(message);
    }
}
