package probstatementeighthinthree;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeSet;

class Book implements Comparable<Book> {
    private int bookId;
    private String title;
    private double price;
    private Date dateOfPublication;
    private String author;

    public Book(int bookId, String title, double price, String author, String dateOfPublication) throws ParseException {
        this.bookId = bookId;
        this.title = title;
        this.price = price;
        this.author = author;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        this.dateOfPublication = sdf.parse(dateOfPublication);
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return bookId + " " + title + " " + price + " " + author + " " + sdf.format(dateOfPublication);
    }

    @Override
    public int hashCode() {
        return bookId;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Book)) return false;
        Book other = (Book) obj;
        return this.bookId == other.bookId;
    }

    @Override
    public int compareTo(Book other) {
        return this.bookId - other.bookId;
    }
}

public class Main {
    public static void main(String[] args) throws ParseException {
        TreeSet<Book> books = new TreeSet<>();
        
        // Adding book details
        books.add(new Book(1001, "Python Learning", 715.0, "Martic C. Brown", "2/2/2020"));
        books.add(new Book(1002, "Modern Mainframe", 295.0, "Sharad", "19/5/1997"));
        books.add(new Book(1003, "Java Programming", 523.0, "Gilad Bracha", "23/11/1984"));
        books.add(new Book(1004, "Read C++", 295.0, "Henry Harvin", "19/11/1984"));
        books.add(new Book(1005, ".Net Platform", 3497.0, "Mark J. Price", "6/3/1984"));

        // Printing all book details
        for (Book book : books) {
            System.out.println(book);
        }
    }
}

