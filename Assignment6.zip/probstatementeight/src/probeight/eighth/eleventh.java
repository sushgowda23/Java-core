package probeight.eighth;


import java.util.Hashtable;

class Employeee {
    private int id;
    private String name;
    private String department;
    private String designation;

    public Employeee(int id, String name, String department, String designation) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.designation = designation;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + designation + " " + department;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Employeee other = (Employeee) obj;
        if (id != other.id)
            return false;
        return true;
    }
}

public class Main {
    public static void main(String[] args) {
        Hashtable<Integer, Employeee> EmployeeeTable = new Hashtable<>();

        // Adding predefined Employeee details
        EmployeeeTable.put(1001, new Employeee(1001, "Daniel", "L&D", "Analyst"));
        EmployeeeTable.put(1002, new Employeee(1002, "Thomas", "Testing", "Tester"));
        EmployeeeTable.put(1003, new Employeee(1003, "Robert", "Development", "Product Manager"));
        EmployeeeTable.put(1004, new Employeee(1004, "Grace", "HR", "Tech Support"));

        // Input for new Employeee
        int newId = 1005;
        String newName = "Charles";
        String newDepartment = "Testing";
        String newDesignation = "QA Lead";

        // Adding new Employeee if not exists
        Employeee newEmployeee = new Employeee(newId, newName, newDepartment, newDesignation);
        if (!EmployeeeTable.containsKey(newId)) {
            EmployeeeTable.put(newId, newEmployeee);
        }

        // Printing all Employeee details
        for (Employeee Employeee : EmployeeeTable.values()) {
            System.out.println(Employeee);
        }
    }
}
