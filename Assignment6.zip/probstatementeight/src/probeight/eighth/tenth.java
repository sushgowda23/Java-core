package probeight.eighth;


import java.util.Hashtable;

class Employeee {
    private int id;
    private String name;
    private String department;
    private String designation;

    public Employeee(int id, String name, String department, String designation) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.designation = designation;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + designation + " " + department;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Employeee other = (Employeee) obj;
        if (id != other.id)
            return false;
        return true;
    }
}

public class tenth {
    public static void main(String[] args) {
        Hashtable<Integer, Employeee> EmployeeeTable = new Hashtable<>();

        // Adding Employeee details
        EmployeeeTable.put(1001, new Employeee(1001, "John Doe", "HR", "HR Manager"));
        EmployeeeTable.put(1002, new Employeee(1002, "Jane Smith", "Finance", "Financial Analyst"));
        EmployeeeTable.put(1003, new Employeee(1003, "Robert", "Development", "Product Manager"));
        EmployeeeTable.put(1004, new Employeee(1004, "Emma Johnson", "Marketing", "Marketing Executive"));

        // Search for a specific Employeee
        int searchId = 1003;
        Employeee Employeee = EmployeeeTable.get(searchId);
        if (Employeee != null) {
            System.out.println(Employeee);
        } else {
            System.out.println("Employeee with ID " + searchId + " not found.");
        }
    }
}
