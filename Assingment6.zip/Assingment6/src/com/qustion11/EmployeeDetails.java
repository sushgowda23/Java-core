package com.qustion11;
 
import java.util.Hashtable;
 
public class EmployeeDetails {
	public static void main(String[] args) {
	
		Hashtable<Integer, Employee> employeeTable = new Hashtable<>();
 
		
		employeeTable.put(1001, new Employee(1001, "John Doe", "Finance", "Manager"));
		employeeTable.put(1002, new Employee(1002, "Jane Smith", "HR", "Director"));
		employeeTable.put(1003, new Employee(1003, "Alice Johnson", "IT", "Software Engineer"));
		employeeTable.put(1004, new Employee(1004, "Bob Brown", "Marketing", "Marketing Manager"));
 
		int newId = 1005;
		if (!employeeTable.containsKey(newId)) {
			employeeTable.put(newId, new Employee(newId, "Charles", "QA", "Lead Testing"));
			System.out.println("Employee added successfully.");
		} else {
			System.out.println("Employee with ID " + newId + " already exists.");
		}
 
	
		System.out.println("Updated Employee Details:");
		for (Employee employee : employeeTable.values()) {
			System.out.println(employee);
		}
	}
}