package com.qustion10;
 
import java.util.Hashtable;
 
public class EmployeeDetails {
	public static void main(String[] args) {
		
		Hashtable<Integer, Employee> employeeTable = new Hashtable<>();
 
		
		employeeTable.put(1001, new Employee(1001, "John Doe", "Finance", "Manager"));
		employeeTable.put(1002, new Employee(1002, "Jane Smith", "HR", "Director"));
		employeeTable.put(1003, new Employee(1003, "Alice Johnson", "IT", "Software Engineer"));
		employeeTable.put(1004, new Employee(1004, "Bob Brown", "Marketing", "Marketing Manager"));
 
		
		int searchId = 1003;
		if (employeeTable.containsKey(searchId)) {
			Employee employee = employeeTable.get(searchId);
			System.out.println("Employee found: " + employee);
		} else {
			System.out.println("Employee with ID " + searchId + " not found.");
		}
	}
}