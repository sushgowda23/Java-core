package com.qustion9;
 
import java.util.Hashtable;
 
public class EmployeeDetails {
	public static void main(String[] args) {
		
		Hashtable<Integer, Employee> employeeTable = new Hashtable<>();
 
		
		employeeTable.put(1, new Employee(1, "John", "Finance", "Manager"));
		employeeTable.put(2, new Employee(2, "Jane", "HR", "Director"));
		employeeTable.put(3, new Employee(3, "Alice", "IT", "Software Engineer"));
		employeeTable.put(4, new Employee(4, "Bob", "Marketing", "Marketing Manager"));
		
		System.out.println("Is Hashtable empty? " + employeeTable.isEmpty());
	}
}