package com.qustion8;
 
import java.util.Map;
import java.util.TreeMap;
 
public class CarDetails {
	public static void main(String[] args) {
		TreeMap<Double, Car> carMap = new TreeMap<>();
 
		// Predefined information of 4 cars
		carMap.put(80050.0, new Car("Bugatti", 80050.0));
		carMap.put(305000.0, new Car("Swift", 305000.0));
		carMap.put(600100.0, new Car("Audi", 600100.0));
		carMap.put(900000.0, new Car("Benz", 900000.0));
 
	
		Map.Entry<Double, Car> greatestEntry = carMap.pollLastEntry();
		System.out.println(greatestEntry.getValue());
 
		
		double key = 80050.0;
		carMap.put(key, new Car("Reva", key));
 
		
		System.out.println(carMap.get(key));
	}
}