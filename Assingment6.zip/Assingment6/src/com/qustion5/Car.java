package com.qustion6;
 
import java.util.Map;
import java.util.TreeMap;
 
class Car implements Comparable<Car> {
	private String name;
	private double price;
 
	public Car(String name, double price) {
		this.name = name;
		this.price = price;
	}
 
	public String getName() {
		return name;
	}
 
	public double getPrice() {
		return price;
	}
 
	@Override
	public String toString() {
		return name + " " + price;
	}
 
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
 
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		return name.equals(other.name) && Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price);
	}
 
	@Override
	public int compareTo(Car other) {
		return Double.compare(other.price, this.price); 
	}
 
}