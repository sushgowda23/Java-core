package com.question3;
 
import java.awt.print.Book;
import java.time.LocalDate;
import java.util.TreeSet;
 
public class BookDetails {
	public static void main(String[] args) {
		TreeSet<Book> books = new TreeSet<>();
 
		
		books.add(new Book(1001, "Python Learning", 715.0, "Martic C. Brown", LocalDate.of(2020, 2, 2)));
		books.add(new Book(1002, "Modern Mainframe", 295.0, "Sharad", LocalDate.of(1997, 5, 19)));
		books.add(new Book(1003, "Java Programming", 523.0, "Gilad Bracha", LocalDate.of(1984, 11, 23)));
		books.add(new Book(1004, "Read C++", 295.0, "Henry Harvin", LocalDate.of(1984, 11, 19)));
		books.add(new Book(1005, ".Net Platform", 3497.0, "Mark J. Price", LocalDate.of(1984, 3, 6)));
 
		System.out.println("Book Details:");
		for (Book book : books) {
			System.out.println(book);
		}
	}
}